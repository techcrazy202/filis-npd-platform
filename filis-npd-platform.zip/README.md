# filis-npd-platform

A platform for NPD (New Product Development) management.